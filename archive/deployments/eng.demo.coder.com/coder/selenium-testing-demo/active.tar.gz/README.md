---
display_name: Scratch
description: A minimal starter template for Coder
icon: ../../../site/static/emojis/1f4e6.png
maintainer_github: coder
verified: true
tags: []
---

# A minimal Scaffolding for a Coder Template

Use this starter template as a basis to create your own unique template from scratch.
