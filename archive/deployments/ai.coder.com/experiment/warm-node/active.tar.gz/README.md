# Node Warmer

### NOTE: This process takes a bit of time (>=5 minutes), depending on the images being pre-cached.

To warm up your nodes, simply launch this workspace in your desired region, or allow the template to automatically warm up nodes on some schedule (using prebuilds!)

TF Variables are used in this template to apply changes globally (i.e. to modify prebuild instances and coder parameters), so modify with caution!

If you need a certain region warmed up, then the easiest thing to do is to launch the workspace in the target region. 

The number of workspaces you configure creates the same number of K8s nodes in the background, warming up instances as needed.