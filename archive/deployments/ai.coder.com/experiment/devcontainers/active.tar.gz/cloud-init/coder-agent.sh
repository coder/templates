#!/usr/bin/env bash

# Only add -x for debugging. Cloud-Init logs will reveal source code with Coder tokens if added.
# https://www.man7.org/linux/man-pages/man1/set.1p.html

set -eu

# Close standard output file descriptor
exec 1<&-
# Close standard error file descriptor
exec 2<&-

# Open standard output as $LOG_FILE file for read and write.
exec 1<>/tmp/coder-init-script.log

# Redirect standard error to standard output
exec 2>&1
sudo PATH="$PATH:/home/${user}/bin" CODER_AGENT_DEVCONTAINERS_ENABLE="${enable_devcontainer_feature}" \
    -u '${user}' sh -c '${init_script}' &
disown ;