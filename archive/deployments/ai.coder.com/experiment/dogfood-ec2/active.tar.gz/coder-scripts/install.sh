#!/usr/bin/env bash

set -eu

sudo su 'root' -c sh -c '
apt update -y
apt install -y \
    curl \
    zip unzip \
    apt-transport-https ca-certificates gnupg software-properties-common

# Add GPG Key Rings to Apt
curl -fsSL https://apt.releases.hashicorp.com/gpg | apt-key add -
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.33/deb/Release.key | apt-key add -
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
curl -fsSL https://baltocdn.com/helm/signing.asc | apt-key add -

# Add to Apt Repos
add-apt-repository -y ppa:deadsnakes
add-apt-repository -y "deb [arch=$(dpkg --print-architecture)] https://apt.releases.hashicorp.com jammy main"
add-apt-repository -y "deb https://pkgs.k8s.io/core:/stable:/v1.33/deb/ /"
add-apt-repository -y "deb [arch=$(dpkg --print-architecture)] https://download.docker.com/linux/ubuntu focal stable"
add-apt-repository -y "deb [arch=$(dpkg --print-architecture)] https://baltocdn.com/helm/stable/debian/ all main"

# Finalize Installations
apt update -y
apt install -y \
    python3.12 python3.12-venv \
    terraform \
    kubectl helm \
    docker docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
'

TMPDIR=$(mktemp -d)
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o $TMPDIR/awscliv2.zip
unzip $TMPDIR/awscliv2.zip -d $TMPDIR
sudo $TMPDIR/aws/install

mkdir "${HOME_FOLDER}/.aws"
cat <<EOF > ${HOME_FOLDER}/.aws/config
[profile demo-coder]
sso_session = demo-coder
sso_account_id = ${ACCOUNT_ID}
sso_role_name = AWSAdministratorAccess
region = ${REGION}
output = json

[sso-session demo-coder]
sso_region = us-east-1
sso_start_url = https://d-9066325a54.awsapps.com/start/#
sso_registration_scopes = sso:account:access
EOF

echo "Finished!"