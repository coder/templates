#!/bin/bash

set -e

while true; do
    echo "$(date) - goose-mock"
    sleep 15
done
