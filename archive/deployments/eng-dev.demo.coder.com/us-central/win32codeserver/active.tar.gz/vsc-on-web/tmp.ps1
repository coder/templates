$PLATFORM = win32
$ARCH = x64
$HASH_URI = "https://update.code.visualstudio.com/api/commits/stable/server-win32-x64-web"
$HASHES = (Invoke-RestMethod -Method "GET" -Uri "https://update.code.visualstudio.com/api/commits/stable/server-win32-x64-web")

$VSCODE_URI = "https://vscode.download.prss.microsoft.com/dbazure/download/stable/e54c774e0add60467559eb0d1e229c6452cf8447/vscode-server-win32-x64-web.zip"

Invoke-RestMethod -Method "GET" -Uri "https://vscode.download.prss.microsoft.com/dbazure/download/stable/e54c774e0add60467559eb0d1e229c6452cf8447/vscode-server-win32-x64-web.zip" -OutFile "$env:TEMP/vscode-server-win32-x64-web.zip"
Expand-Archive -Path "$env:TEMP/vscode-server-win32-x64-web.zip" -DestinationPath "./"

./vscode-server-win32-x64-web/bin/code-server.cmd serve-local \
    --server-base-path=${SERVER_BASE_PATH} \
    --port 90312 \
    --host 127.0.0.1 \
    --accept-server-license-terms \
    --without-connection-token \
    --telemetry-level all \
    --log trace

New-Item "C:\Users\Administrator\install.ps1"

$Content=@'
$HASHES = (Invoke-RestMethod -Method "GET" -Uri "https://update.code.visualstudio.com/api/commits/stable/server-win32-x64-web");

Write-Output "Current Location: $(Get-Location)"
Write-Output "$HASHES";

$VSCODE_URI = "https://vscode.download.prss.microsoft.com/dbazure/download/stable/e54c774e0add60467559eb0d1e229c6452cf8447/vscode-server-win32-x64-web.zip";

Invoke-RestMethod `
    -Method "GET" `
    -Uri "https://vscode.download.prss.microsoft.com/dbazure/download/stable/e54c774e0add60467559eb0d1e229c6452cf8447/vscode-server-win32-x64-web.zip" `
    -OutFile "$env:TEMP/vscode-server-win32-x64-web.zip";

Write-Output "CWD: $(Get-Location)"
Write-Output "ZIP in $env:TEMP: $(Get-ChildItem \"$env:TEMP/vscode-server-win32-x64-web.zip\")";

Expand-Archive -Path "$env:TEMP/vscode-server-win32-x64-web.zip" -DestinationPath "./";

Write-Output "VSCode in CWD: $(Get-ChildItem \"./vscode-server-win32-x64-web/\")"
Write-Output "Starting code-server.cmd";

./vscode-server-win32-x64-web/bin/code-server.cmd serve-local `
    --server-base-path=C:\Users\Administrator `
    --host 127.0.0.1 --port 1029 `
    --accept-server-license-terms `
    --without-connection-token `
    --telemetry-level all `
    --log trace;
'@

$Content=@'
./vscode-server-win32-x64-web/bin/code-server.cmd serve-local `
    --host 127.0.0.1 --port 1029 `
    --accept-server-license-terms `
    --without-connection-token `
    --telemetry-level all `
    --log trace;
'@

$Content | Set-Content "C:\Users\Administrator\install.ps1"

$proc = Start-Process -PassThru -WindowStyle Hidden -FilePath "C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd" `
    -ArgumentList "serve-local","--host 127.0.0.1","--port 1029","--accept-server-license-terms","--without-connection-token","--telemetry-level all","--log trace" `
    -Credential $credential

    
$args = "serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace"
Start-Process powershell.exe `
    -Credential $credential `
    -Confirm -PassThru `
    -ArgumentList "-Command {C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace}";

Start-Process "code-server.cmd" -WorkingDirectory "C:\Users\JuPepe\vscode-server-win32-x64-web\bin\"

Invoke-Item -Path "C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd" "serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace"
cmd.exe /c "C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd" "serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace"

$PROC = Start-Process -PassThru -Credential $credential "C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd" @"
serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace
"@

Start-Process -PassThru "C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd" @"
serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace
"@

$securePassword = ConvertTo-SecureString "P@ssw0rd123" -AsPlainText -Force;
$cred = New-Object System.Management.Automation.PSCredential("JuPepe", $securePassword);
$s = New-PSSession -ComputerName . -Credential $cred
Invoke-Command `
    -Session $s
    -ScriptBlock { C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace }


$PROC = Start-Process -Verb RunAsUser powershell -PassThru -Credential $credential -RedirectStandardError "error.txt" -RedirectStandardOutput "output.txt" -ArgumentList "-Command",@"
C:\Users\JuPepe\vscode-server-win32-x64-web\bin\code-server.cmd serve-local --host 127.0.0.1 --port 1029 --accept-server-license-terms --without-connection-token --telemetry-level all --log trace
"@