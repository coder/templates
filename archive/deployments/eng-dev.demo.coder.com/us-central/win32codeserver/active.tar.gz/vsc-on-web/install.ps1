$username = "JuPepe"
$password = "P@ssw0rd123"
$securePassword = ConvertTo-SecureString $password -AsPlainText -Force;
net user administrator $password
net user $username $password /add
net localgroup Administrators $username /add
net localgroup "Remote Management Users" $username /add
WMIC USERACCOUNT WHERE "Name='$username'" SET PasswordExpires=FALSE

Enable-PSRemoting -Force
$env:HostIPv4 = (Get-NetIPAddress -AddressFamily IPv4 -PrefixOrigin Dhcp).IPv4Address
winrm s winrm/config/client "@{TrustedHosts=`"localhost`"}"
winrm quickconfig -quiet -force

# $HASHES = (Invoke-RestMethod -Method "GET" -Uri "https://update.code.visualstudio.com/api/commits/stable/server-win32-x64-web");
# Write-Output "Downloading VSCode zip.";

$VSCODE_URI = "https://vscode.download.prss.microsoft.com/dbazure/download/stable/e54c774e0add60467559eb0d1e229c6452cf8447/vscode-server-win32-x64-web.zip";

Invoke-RestMethod `
    -Method "GET" `
    -Uri "https://vscode.download.prss.microsoft.com/dbazure/download/stable/e54c774e0add60467559eb0d1e229c6452cf8447/vscode-server-win32-x64-web.zip" `
    -OutFile "$env:TEMP/vscode-server-win32-x64-web.zip";

Write-Output "CWD: $(Get-Location)";
Write-Output "ZIP in $env:TEMP: $(Get-ChildItem $env:TEMP)";

Expand-Archive -Path "$env:TEMP\vscode-server-win32-x64-web.zip" -DestinationPath "C:\Users\$username";


New-Item -Path "$env:TEMP\vscode-web.log" -ItemType File
$ScriptBlock = {
    Param($VSCODE_PATH)
    Set-Location -Path "$VSCODE_PATH"; 
    Get-Location;
    .\code-server.cmd serve-local `
        --host 127.0.0.1 `
        --port 1029 `
        --accept-server-license-terms `
        --without-connection-token `
        --telemetry-level all `
        --log trace 2>&1 >> $env:TEMP\vscode-web.log;
}
$username = "JuPepe"
$password = "P@ssw0rd123"
$securePassword = ConvertTo-SecureString $password -AsPlainText -Force;
$cred = New-Object System.Management.Automation.PSCredential($username, $securePassword);
$s = New-PSSession -Credential $cred -ComputerName "localhost"
Invoke-Command -AsJob -Session $s -ScriptBlock $ScriptBlock -ArgumentList "C:\Users\$username\vscode-server-win32-x64-web\bin"